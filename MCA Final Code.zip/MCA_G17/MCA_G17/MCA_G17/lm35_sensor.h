/* 
   File: lm35_sensor.h
   Description: Header file for LM35 sensor, including the function declaration to get temperature.
               
   MCA SCE: Microcontroller-based Overheat Detector using Temperature Sensor with Buzzer Indication
   Application: Refrigerated Truck
   Group Members: Manas Kulkarni, Rajlakshmi Desai, Samiksha Nalawade, Dhanashree Biradar
   Group Number: A35
 */

#ifndef LM35_SENSOR_H_
#define LM35_SENSOR_H_

#include "adc.h"  // Include the ADC header file to use ADC functions

#define SENSOR_MAX_TEMPERATURE   150  // Define the maximum temperature limit for the LM35 sensor (in Celsius)
#define SENSOR_MAX_VOLTAGE       1.5  // Define the maximum voltage output by the LM35 sensor
#define SENSOR_CHANNEL_ID        2    // Define the ADC channel ID to which the LM35 is connected

uint8 LM35_GetTemperature(void);  // Declare the function to get the temperature from LM35 sensor

#endif  // End of the header guard