/* 
 File: i2c.c
 Description: I2C communication functions for master mode communication in AVR-based microcontrollers.
              Provides functions for initialization, starting a transmission, sending data, receiving data,
              and stopping the communication.
              
 MCA SCE: Microcontroller based Overheat detector using Temperature sensor with Buzzer indication
 Application: Refrigerated Truck
 Group Members: Manas Kulkarni, Rajlakshmi Desai, Samiksha Nalawade, Dhanashree Biradar
 Group Number: A35
 */

#define F_CPU 12000000UL  // Define CPU frequency
#include <util/delay.h>
#include <avr/io.h>
#include "i2c.h"

// Variable to track whether the current operation is master mode or not
static bool masterMode;

/* Function to initialize the I2C communication */
void i2c_init(void)
{
    TWSR &= ~((1 << TWPS1) | (1 << TWPS0));  // Set pre-scaler to 1
    TWBR = ((F_CPU / F_I2C) - 16) / 2;        // Calculate the baud rate factor
}

/* Function to start I2C transmission (either master or slave) */
uint8_t i2c_tx_start(bool mode)
{
    int8_t status = 0;
    masterMode = mode; // Set global state of read/write bit

    // Clear interrupt flag, issue start command (gain control of bus as master), enable I2C
    TWCR |=  (1 << TWINT) | (1 << TWSTA) | (1 << TWEN);

    // Wait until the start condition is transmitted
    while (!(TWCR & (1 << TWINT)));

    // Check the status of the transmission
    switch (TWSR & 0xF8) {
        case 0x08:  // Start condition sent from master
        case 0x10:  // Repeat start condition sent from master
            status = TRANSMISSION_SUCCESS;
            break;
        default:
            status = TRANSMISSION_ERROR;
            break;
    }

    return status;
}

/* Function to send I2C address */
uint8_t i2c_tx_address(uint8_t address)
{
    int8_t status = 0;

    TWDR = (address << 1) | masterMode;  // Load address with R/W bit based on master mode
    TWCR = (1 << TWINT | 1 << TWEN);     // Clear interrupt and enable I2C

    // Wait until the address is transmitted
    while (!(TWCR & (1 << TWINT)));

    // Check the status for transmission of the address
    if (masterMode == MASTER_TRANSMITTER) {
        switch (TWSR & 0xF8) {
            case 0x18:  // Address|Write sent and ACK returned
                status = TRANSMISSION_SUCCESS;
                break;
            case 0x20:  // Address|Write sent and NACK returned by slave
            case 0x38:  // Bus failure detected
                status = TRANSMISSION_ERROR;
                break;
            default:
                status = TRANSMISSION_ERROR;
                break;
        }
    } else if (masterMode == MASTER_RECEIVER) {
        switch (TWSR & 0xF8) {
            case 0x40:  // Address|Read sent and ACK returned
                status = TRANSMISSION_SUCCESS;
                break;
            case 0x48:  // Address|Read sent and NACK returned
            case 0x38:  // Bus failure detected
                status = TRANSMISSION_ERROR;
                break;
            default:
                status = TRANSMISSION_ERROR;
                break;
        }
    }

    return status;
}

/* Function to send a byte of data via I2C */
uint8_t i2c_tx_byte(uint8_t byteData)
{
    int8_t status = 0;
    TWDR = byteData;  // Load data buffer with data to be transmitted
    TWCR |= (1 << TWINT);  // Clear interrupt flag

    // Wait until the data is transmitted
    while (!(TWCR & (1 << TWINT)));

    // Check the transmission status
    switch (TWSR & 0xF8) {
        case 0x28:  // Byte sent and ACK returned
            status = TRANSMISSION_SUCCESS;
            break;
        case 0x30:  // Byte sent and NACK returned
        case 0x38:  // Bus failure detected
            status = TRANSMISSION_ERROR;
            break;
        default:
            status = TRANSMISSION_ERROR;
            break;
    }

    return status;
}

/* Function to detect I2C bus timeout */
int8_t i2c_timeout(void)
{
    uint8_t time = TIMEOUT;
    int8_t status = BUS_DISCONNECTED;

    // Wait for timeout
    while (time-- > 0) {
        if ((TWCR & (1 << TWINT))) {  // Check if bus is ready
            status = BUS_CONNECTED;
            break;
        }
    }

    return status;
}

/* Function to receive a byte of data from I2C */
uint8_t i2c_rx_byte(bool response)
{
    int8_t status;

    // Clear interrupt flag and set response type
    TWCR = (1 << TWINT) | ((response & 0xFE) << TWEA) | (1 << TWEN);

    // Detect bus timeout
    if (i2c_timeout() != BUS_DISCONNECTED) {
        // Check the reception status
        switch (TWSR & 0xF8) {
            case 0x50:  // Data byte read and ACK returned by master
            case 0x58:  // Data byte read and NACK returned by master
                status = TWDR;  // Return received data
                break;
            case 0x38:  // Bus failure detected
                status = TRANSMISSION_ERROR;
                break;
            default:
                status = TRANSMISSION_ERROR;
                break;
        }
    } else {
        status = TRANSMISSION_ERROR;  // Bus timeout error
    }

    return status;
}

/* Function to stop I2C communication */
void i2c_tx_stop(void)
{
    // Clear interrupt flag, issue stop command
    TWCR |= (1 << TWINT) | (1 << TWSTO);

    // Wait until stop condition is transmitted
    while ((TWCR & (1 << TWSTO)));
}