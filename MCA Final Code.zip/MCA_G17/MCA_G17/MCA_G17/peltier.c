/* 
   File: peltier.c
   Description: This file contains functions to initialize and control the Peltier module 
                using PWM (Pulse Width Modulation) based on the temperature input.
   MCA SCE: Microcontroller-based Overheat Detector using Temperature Sensor with Buzzer Indication
   Application: Refrigerated Truck
   Group Members: Manas Kulkarni, Rajlakshmi Desai, Samiksha Nalawade, Dhanashree Biradar
   Group Number: A35
 */

#include <avr/io.h>
#include "gpio.h"

/* 
 * Function to initialize the Peltier module. It configures PB3 as output for PWM control 
 * and sets up the timer for Fast PWM mode with a prescaler of 64.
 */
void Peltier_Init(void)
{
	// Set PB3 as an output pin for PWM control of the Peltier module
	GPIO_setupPinDirection(PORTB_ID, PB3, PIN_OUTPUT);

	// Fast PWM mode, non-inverting, prescaler = 64
	TCCR2A = (1 << COM2A1) | (1 << WGM21) | (1 << WGM20);  // Configure Fast PWM, non-inverting
	TCCR2B = (1 << CS22);  // Set prescaler to 64
}

/* 
 * Function to control the Peltier module based on the temperature.
 * It adjusts the duty cycle of the PWM signal based on the temperature.
 * Arguments:
 *    temp - The current temperature value.
 * Returns:
 *    duty - The duty cycle percentage used for PWM control.
 */
uint8 Peltier_Control(uint8 temp)
{
	uint8 duty = 0;

	// Adjust duty cycle based on the temperature
	if (temp > 10)
	{
		if (temp > 20)
			duty = 100;  // Set duty to 100% if temperature is above 20�C
		else if (temp > 17)
			duty = 75;   // Set duty to 75% if temperature is between 17�C and 20�C
		else if (temp > 14)
			duty = 50;   // Set duty to 50% if temperature is between 14�C and 17�C
		else
			duty = 25;   // Set duty to 25% if temperature is between 10�C and 14�C

		// Set PWM duty cycle (OCR2A determines the duty cycle)
		OCR2A = (duty * 255) / 100;
	}
	else
	{
		// Turn off Peltier if temperature is below or equal to 10�C
		OCR2A = 0;
	}

	return duty; // Return the current duty cycle for display or other use
}