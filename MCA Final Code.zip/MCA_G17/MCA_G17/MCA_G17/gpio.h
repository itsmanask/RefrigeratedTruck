/* 
   File: gpio.h
   Description: Contains macros and function prototypes for GPIO operations such as setting pin direction, reading and writing pin values,
                and configuring port direction for microcontroller IO pins.
                
   MCA SCE: Microcontroller-based Overheat Detector using Temperature Sensor with Buzzer Indication
   Application: Refrigerated Truck
   Group Members: Manas Kulkarni, Rajlakshmi Desai, Samiksha Nalawade, Dhanashree Biradar
   Group Number: A35
 */

#ifndef GPIO_H_
#define GPIO_H_

#include "std_types.h"     // Standard types like uint8, uint16, etc.
#include "Macros.h"        // Macros like SET_BIT, CLEAR_BIT, etc.
#include <avr/io.h>        // I/O port register definitions

#define NUM_OF_PORTS           4     // Total number of I/O ports (A to D)
#define NUM_OF_PINS_PER_PORT   8     // Number of pins per port (0 to 7)

#define PORTA_ID               0     // ID for PORTA
#define PORTB_ID               1     // ID for PORTB
#define PORTC_ID               2     // ID for PORTC
#define PORTD_ID               3     // ID for PORTD

#define PIN0_ID                0     // ID for PIN0
#define PIN1_ID                1     // ID for PIN1
#define PIN2_ID                2     // ID for PIN2
#define PIN3_ID                3     // ID for PIN3
#define PIN4_ID                4     // ID for PIN4
#define PIN5_ID                5     // ID for PIN5
#define PIN6_ID                6     // ID for PIN6
#define PIN7_ID                7     // ID for PIN7

#define BUZZER_PORT_ID         PORTD_ID  // Buzzer connected to PORTD
#define BUZZER_PIN_ID          PIN7_ID   // Buzzer connected to PIN7 of PORTD

// Enum for pin direction
typedef enum
{
	PIN_INPUT,             // Configure pin as input
	PIN_OUTPUT             // Configure pin as output
} GPIO_PinDirectionType;

// Enum for port direction
typedef enum
{
	PORT_INPUT,            // Configure port as input (all pins)
	PORT_OUTPUT = 0xFF     // Configure port as output (all pins)
} GPIO_PortDirectionType;

// Function prototypes
void GPIO_setupPinDirection(uint8 port_num, uint8 pin_num, GPIO_PinDirectionType direction);
void GPIO_writePin(uint8 port_num, uint8 pin_num, uint8 value);
uint8 GPIO_readPin(uint8 port_num, uint8 pin_num);
void GPIO_setupPortDirection(uint8 port_num, uint8 direction);
void GPIO_writePort(uint8 port_num, uint8 value);
uint8 GPIO_readPort(uint8 port_num);

#endif /* GPIO_H_ */