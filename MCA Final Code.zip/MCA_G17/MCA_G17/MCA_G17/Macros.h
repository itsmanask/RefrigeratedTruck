/* 
   File: Macros.h
   Description:   Contains macros to manipulate individual bits
   *              in registers. These macros provide an efficient way to perform
   *              common bit-level operations like setting, clearing, toggling,
   *              and rotating bits in microcontroller registers.
               
   MCA SCE: Microcontroller-based Overheat Detector using Temperature Sensor with Buzzer Indication
   Application: Refrigerated Truck
   Group Members: Manas Kulkarni, Rajlakshmi Desai, Samiksha Nalawade, Dhanashree Biradar
   Group Number: A35
 */

#ifndef MACROS_H_
#define MACROS_H_

/* 
 * Set a bit in the required register
 * This macro performs a bitwise OR operation to set a specific bit in the register.
 * Example usage: SET_BIT(PORTB, 2);  // Sets bit 2 of PORTB
 */
#define SET_BIT(REG,BIT)       ( REG |= (1 << BIT) )

/* 
 * Clear a bit in the required register
 * This macro performs a bitwise AND operation with the complement to clear a specific bit in the register.
 * Example usage: CLEAR_BIT(PORTB, 2);  // Clears bit 2 of PORTB
 */
#define CLEAR_BIT(REG,BIT)     ( REG &= ~(1 << BIT) )

/* 
 * Toggle a bit in the required register
 * This macro performs a bitwise XOR operation to toggle a specific bit in the register.
 * Example usage: TOGGLE_BIT(PORTB, 2);  // Toggles bit 2 of PORTB
 */
#define TOGGLE_BIT(REG,BIT)    ( REG ^= (1 << BIT) )

/* 
 * Write a specific bit in the required register according to the value to be passed (1 or 0)
 * This macro writes a value of 1 or 0 to a specific bit in the register.
 * Example usage: WRITE_BIT(PORTB, 2, 1);  // Sets bit 2 of PORTB to 1
 */
#define WRITE_BIT(REG,BIT,VAL){\
      switch(VAL){\
      case 0:\
    	  CLEAR_BIT(REG,BIT); break;\
      case 1:\
    	  SET_BIT(REG,BIT); break;\
      }\
}

/* 
 * Rotate right the register value with a specific number of rotates
 * This macro rotates the register value to the right by a specified number of bits.
 * Example usage: ROR(PORTB, 2);  // Rotate bits of PORTB right by 2 positions
 */
#define ROR(REG,BIT)          ( REG = (REG >> BIT) | (REG << (8 - BIT)) )

/* 
 * Rotate left the register value with a specific number of rotates
 * This macro rotates the register value to the left by a specified number of bits.
 * Example usage: ROL(PORTB, 2);  // Rotate bits of PORTB left by 2 positions
 */
#define ROL(REG,BIT)          ( REG = (REG << BIT) | (REG >> (8 - BIT)) )

/* 
 * Checks if a bit is set in the required register and return 1 if TRUE and 0 Otherwise
 * This macro checks if a specific bit is set (1) in the register.
 * Example usage: BIT_IS_SET(PORTB, 2);  // Returns 1 if bit 2 of PORTB is set
 */
#define BIT_IS_SET(REG,BIT)    ( REG & (1 << BIT))

/* 
 * Checks if a bit is cleared in the required register and return 1 if TRUE and 0 Otherwise
 * This macro checks if a specific bit is cleared (0) in the register.
 * Example usage: BIT_IS_CLEAR(PORTB, 2);  // Returns 1 if bit 2 of PORTB is cleared
 */
#define BIT_IS_CLEAR(REG,BIT)  ( !(BIT_IS_SET(REG,BIT)) )

/* 
 * Return the value of a bit in the required register (1 or 0)
 * This macro returns the value of the specified bit (either 1 or 0).
 * Example usage: GET_BIT(PORTB, 2);  // Returns the value of bit 2 of PORTB
 */
#define GET_BIT(REG,BIT)       ( BIT_IS_SET(REG,BIT)? 1 : 0 )

#endif /* MACROS_H_ */
