/* 
   File: Fan_Controller.c
   Description: Main program for controlling the refrigerated truck system.
                It handles the fan, Peltier module, and buzzer control based on the temperature
                and displays the relevant information on an OLED screen.
               
   MCA SCE: Microcontroller-based Overheat Detector using Temperature Sensor with Buzzer Indication
   Application: Refrigerated Truck
   Group Members: Manas Kulkarni, Rajlakshmi Desai, Samiksha Nalawade, Dhanashree Biradar
   Group Number: A35
 */

#include "lm35_sensor.h"
#include "i2c.h"
#include "SSD1306.h"
#include "dc_motor.h"
#include <avr/io.h>
#include "peltier.h"

#define F_CPU 12000000UL  // Define clock frequency
#include <util/delay.h>
#include "adc.h"

int main(void)
{
	// Initialize the buzzer port for output
	GPIO_setupPinDirection(BUZZER_PORT_ID, BUZZER_PIN_ID, PIN_OUTPUT);
	GPIO_writePin(BUZZER_PORT_ID, BUZZER_PIN_ID, LOGIC_LOW); // Buzzer initially OFF
	
	uint8 tempValue = 0;       // Variable to store temperature value
	uint8 speedValue = 0;      // Variable to store motor speed value
	uint16_t buzzer_timer = 0; // Timer for buzzer (to keep it on for 2 sec intervals)

	// ADC configuration to initialize ADC with specific prescaler and reference voltage
	ADC_ConfigType Config;
	Config.prescaler = FCPU_8; // Set prescaler for ADC
	Config.ref_volt = AVCC;    // Set reference voltage to AVCC
	ADC_init(&Config);         // Initialize ADC with the given configuration

	// Initialize I2C, OLED, DC Motor, and Peltier module
	i2c_init();    
	OLED_Init();   
	OLED_Clear();  
	DcMotor_Init();
	Peltier_Init(); // Call after DcMotor_Init()

	while(1)
	{
		// Get the current temperature from the LM35 sensor
		tempValue = LM35_GetTemperature();

		// Set the cursor position and display the fan status
		OLED_SetCursor(0, 0);
		OLED_DisplayString((uint8_t *)"FAN IS ");

		// Logic to control the fan speed based on the temperature
		if (tempValue <= 10)
		{
			OLED_DisplayString((uint8_t *)"OFF ");
			DcMotor_Rotate(STOP, 0,0 );  // Stop the motor
			speedValue = 0;           // Set speed to 0
		}
		else
		{
			OLED_DisplayString((uint8_t *)"ON  ");

			// Set fan speed based on temperature ranges
			if(tempValue >= 20)
				speedValue = 100;
			else if(tempValue >= 17)
				speedValue = 75;
			else if(tempValue >= 14)
				speedValue = 50;
			else
				speedValue = 25;

			// Rotate motors in clockwise with speed for both motors
			DcMotor_Rotate(ClockWise, speedValue, speedValue);

		}

		// Get the duty cycle of the Peltier module based on the temperature
		uint8 peltierDuty = Peltier_Control(tempValue); // Get current duty
		OLED_SetCursor(4, 0);
		OLED_DisplayString((uint8_t *)"PELTIER: ");
		OLED_DisplayNumber(C_DECIMAL_U8, peltierDuty, 3);  // Display Peltier duty cycle
		OLED_DisplayString((uint8_t *)"%");

		// Buzzer logic: alert if temperature > 10�C
		if (tempValue > 10)
		{
			// Buzzer alert every 2 seconds
			if (buzzer_timer == 0)
			{
				GPIO_writePin(BUZZER_PORT_ID, BUZZER_PIN_ID, LOGIC_HIGH);  // Turn on the buzzer
				_delay_ms(200);  // Wait for 200ms
				GPIO_writePin(BUZZER_PORT_ID, BUZZER_PIN_ID, LOGIC_LOW);   // Turn off the buzzer
				buzzer_timer = 4;  // Reset buzzer timer to trigger after 2 seconds
			}
			else
			{
				buzzer_timer--;  // Decrease timer for next cycle
			}
		}
		else
		{
			GPIO_writePin(BUZZER_PORT_ID, BUZZER_PIN_ID, LOGIC_LOW);  // Turn off the buzzer
			buzzer_timer = 0;  // Reset the buzzer timer
		}

		// Display the temperature value on the OLED screen
		OLED_SetCursor(1, 0);
		OLED_DisplayString((uint8_t *)"TEMP = ");
		OLED_DisplayNumber(C_DECIMAL_U8, tempValue, 3);  // Display temperature
		OLED_DisplayString((uint8_t *)" C");

		// Display the motor speed on the OLED screen
		OLED_SetCursor(3, 0);
		OLED_DisplayString((uint8_t *)"SPEED: ");
		OLED_DisplayNumber(C_DECIMAL_U8, speedValue, 3);  // Display fan speed

		_delay_ms(500);  // Wait for half a second before updating the screen
	}
}