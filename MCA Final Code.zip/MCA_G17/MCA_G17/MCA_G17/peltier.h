/* 
   File: peltier.h
   Description: Header file for controlling the Peltier module, providing functions to initialize and control
                the PWM duty cycle based on temperature to manage the Peltier module's power.
               
   MCA SCE: Microcontroller-based Overheat Detector using Temperature Sensor with Buzzer Indication
   Application: Refrigerated Truck
   Group Members: Manas Kulkarni, Rajlakshmi Desai, Samiksha Nalawade, Dhanashree Biradar
   Group Number: A35
 */

#ifndef PELTIER_H_
#define PELTIER_H_

#include "std_types.h"  // Include standard types for uint8, uint16, etc.

/* 
   Function: Peltier_Init
   Description: Initializes the Peltier control by setting up the PWM pin and configuring PWM parameters.
*/
void Peltier_Init(void);

/* 
   Function: Peltier_Control
   Description: Controls the duty cycle of the Peltier module based on the temperature.
   Input: temp - Current temperature value (in Celsius)
   Output: uint8 - Duty cycle percentage (0-100%)
*/
uint8 Peltier_Control(uint8 temp);  // Function now returns the duty cycle percentage

#endif