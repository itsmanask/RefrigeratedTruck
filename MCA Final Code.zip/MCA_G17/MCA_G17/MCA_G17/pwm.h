/* 
   File: pwm.h
   Description: Header file that declares functions for controlling PWM using Timer0.
                PWM output can be controlled by setting the desired duty cycle.
               
   MCA SCE: Microcontroller-based Overheat Detector using Temperature Sensor with Buzzer Indication
   Application: Refrigerated Truck
   Group Members: Manas Kulkarni, Rajlakshmi Desai, Samiksha Nalawade, Dhanashree Biradar
   Group Number: A35
 */

#ifndef PWM_H_         // Include guard to prevent multiple inclusions
#define PWM_H_

#include "gpio.h"      // Include GPIO header for pin definitions and functions

#define OC0_PORT_ID        PORTB_ID   // Define the port for OC0 (PWM output)
#define OC0_PIN_ID         PIN3_ID    // Define the pin for OC0 (PWM output)

void PWM_Timer0_Start(uint8 duty_cycle);  // Declare the function to start Timer0 PWM with given duty cycle
void PWM_Timer1_Start(uint8 dutyCycleMotor1, uint8 dutyCycleMotor2);

#endif