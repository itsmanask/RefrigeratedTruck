/* 
   File: gpio.c
   Description: Source file for GPIO driver functions to configure, write, and read ports/pins on AVR.
   
   MCA SCE: Microcontroller-based Overheat Detector using Temperature Sensor with Buzzer Indication
   Application: Refrigerated Truck
   Group Members: Manas Kulkarni, Rajlakshmi Desai, Samiksha Nalawade, Dhanashree Biradar
   Group Number: A35
 */

#include "gpio.h"

// Set direction of a specific pin (input/output)
void GPIO_setupPinDirection(uint8 portNum, uint8 pinNum, GPIO_PinDirectionType direction)
{
	if ((pinNum >= NUM_OF_PINS_PER_PORT) || (portNum >= NUM_OF_PORTS))
		return;

	if (direction == PIN_OUTPUT)
	{
		switch (portNum)
		{
		case PORTB_ID: SET_BIT(DDRB, pinNum); break;
		case PORTC_ID: SET_BIT(DDRC, pinNum); break;
		case PORTD_ID: SET_BIT(DDRD, pinNum); break;
		}
	}
	else if (direction == PIN_INPUT)
	{
		switch (portNum)
		{
		case PORTB_ID: CLEAR_BIT(DDRB, pinNum); break;
		case PORTC_ID: CLEAR_BIT(DDRC, pinNum); break;
		case PORTD_ID: CLEAR_BIT(DDRD, pinNum); break;
		}
	}
}

// Write logic value to a specific pin
void GPIO_writePin(uint8 port_num, uint8 pin_num, uint8 value)
{
	if ((pin_num >= NUM_OF_PINS_PER_PORT) || (port_num >= NUM_OF_PORTS))
		return;

	switch (port_num)
	{
	case PORTB_ID: WRITE_BIT(PORTB, pin_num, value); break;
	case PORTC_ID: WRITE_BIT(PORTC, pin_num, value); break;
	case PORTD_ID: WRITE_BIT(PORTD, pin_num, value); break;
	}
}

// Read logic value from a specific pin
uint8 GPIO_readPin(uint8 port_num, uint8 pin_num)
{
	uint8 pinValue = LOGIC_LOW;

	if ((pin_num >= NUM_OF_PINS_PER_PORT) || (port_num >= NUM_OF_PORTS))
		return LOGIC_LOW;

	switch (port_num)
	{
	case PORTB_ID: pinValue = GET_BIT(PINB, pin_num); break;
	case PORTC_ID: pinValue = GET_BIT(PINC, pin_num); break;
	case PORTD_ID: pinValue = GET_BIT(PIND, pin_num); break;
	}

	return pinValue;
}

// Set direction of an entire port (input/output)
void GPIO_setupPortDirection(uint8 port_num, GPIO_PortDirectionType direction)
{
	if (port_num >= NUM_OF_PORTS)
		return;

	switch (port_num)
	{
	case PORTB_ID: DDRB = direction; break;
	case PORTC_ID: DDRC = direction; break;
	case PORTD_ID: DDRD = direction; break;
	}
}

// Write value to an entire port
void GPIO_writePort(uint8 port_num, uint8 value)
{
	if (port_num >= NUM_OF_PORTS)
		return;

	switch (port_num)
	{
	case PORTB_ID: PORTB = value; break;
	case PORTC_ID: PORTC = value; break;
	case PORTD_ID: PORTD = value; break;
	}
}

// Read value from an entire port
uint8 GPIO_readPort(uint8 port_num)
{
	uint8 portValue = LOGIC_LOW;

	if (port_num >= NUM_OF_PORTS)
		return LOGIC_LOW;

	switch (port_num)
	{
	case PORTB_ID: portValue = PINB; break;
	case PORTC_ID: portValue = PINC; break;
	case PORTD_ID: portValue = PIND; break;
	}

	return portValue;
}