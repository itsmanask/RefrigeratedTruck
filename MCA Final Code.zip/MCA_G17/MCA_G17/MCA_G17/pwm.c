#include <avr/io.h>
#include "pwm.h"

void PWM_Timer1_Start(uint8 dutyCycleMotor1, uint8 dutyCycleMotor2)
{
	// Set PB1/OC1A and PB2/OC1B as output
	DDRB |= (1 << PB1) | (1 << PB2);

	// Set Fast PWM mode with ICR1 as top
	TCCR1A = (1 << COM1A1) | (1 << COM1B1) | (1 << WGM11);
	TCCR1B = (1 << WGM13) | (1 << WGM12) | (1 << CS11); // Prescaler = 8

	// Set TOP value for 1kHz PWM
	ICR1 = 999;

	// Set duty cycles for Motor1 and Motor2
	OCR1A = (dutyCycleMotor1 * ICR1) / 100;
	OCR1B = (dutyCycleMotor2 * ICR1) / 100;
}
