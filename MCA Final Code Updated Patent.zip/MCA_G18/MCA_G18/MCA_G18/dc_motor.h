#ifndef DC_MOTOR_H_
#define DC_MOTOR_H_

#include "gpio.h"

// Motor port and pin IDs
#define MOTOR_PINS_PORT_ID         PORTB_ID

#define MOTOR_IN1_PIN_ID           PIN0_ID
#define MOTOR_IN2_PIN_ID           PIN1_ID
#define MOTOR_IN3_PIN_ID           PIN2_ID
#define MOTOR_IN4_PIN_ID           PIN3_ID

typedef enum{
	STOP,
	Anti_ClockWise,
	ClockWise
}DcMotor_State;

// Updated: rotate function accepts two speeds
void DcMotor_Init(void);
void DcMotor_Rotate(DcMotor_State state, uint8 speedMotor1, uint8 speedMotor2);

#endif /* DC_MOTOR_H_ */
