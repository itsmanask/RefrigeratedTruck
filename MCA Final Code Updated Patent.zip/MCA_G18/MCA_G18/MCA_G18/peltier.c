/* 
   File: peltier.c
   Description: This file contains functions to initialize and control the Peltier module 
                using PWM (Pulse Width Modulation) based on the temperature input.
   MCA SCE: Microcontroller-based Overheat Detector using Temperature Sensor with Buzzer Indication
   Application: Refrigerated Truck
   Group Members: Manas Kulkarni, Rajlakshmi Desai, Samiksha Nalawade, Dhanashree Biradar
   Group Number: A35
 */

#include <avr/io.h>
#include "gpio.h"

void Peltier_Init(void)
{
	// Set PB3 as output pin for PWM control
	GPIO_setupPinDirection(PORTB_ID, PB3, PIN_OUTPUT);

	// Fast PWM mode, non-inverting, prescaler = 64
	TCCR2A = (1 << COM2A1) | (1 << WGM21) | (1 << WGM20);
	TCCR2B = (1 << CS22);
}

/*
 * Adaptive Peltier Control: Scales duty cycle smoothly from 0% to 100% between 10�C to 18�C
 */
uint8 Peltier_Control(uint8 temp)
{
	uint8 duty = 0;

	if (temp > 10)
	{
		if (temp >= 18)
			duty = 100;
		else
			duty = (uint8)((temp - 10) * 12.5);  // Scale: 8�C range to 100%
		
		OCR2A = (duty * 255) / 100;  // Convert % to 8-bit PWM
	}
	else
	{
		OCR2A = 0;
		duty = 0;
	}

	return duty;
}
