/* 
   File: std_types.h
   Description: This file defines common data types used throughout the project.
                It includes standard boolean values, logic levels, pointer types, and integer types.
               
   MCA SCE: Microcontroller-based Overheat Detector using Temperature Sensor with Buzzer Indication
   Application: Refrigerated Truck
   Group Members: Manas Kulkarni, Rajlakshmi Desai, Samiksha Nalawade, Dhanashree Biradar
   Group Number: A35
 */

#ifndef STD_TYPES_H_  // Include guard to prevent multiple inclusions
#define STD_TYPES_H_

/* Boolean Data Type */
typedef unsigned char boolean;   // Define a boolean data type as unsigned char

/* Boolean Values */
#ifndef FALSE
#define FALSE       (0u)   // Define FALSE as 0 if not already defined
#endif
#ifndef TRUE
#define TRUE        (1u)   // Define TRUE as 1 if not already defined
#endif

#define LOGIC_HIGH        (1u)   // Define LOGIC_HIGH as 1
#define LOGIC_LOW         (0u)   // Define LOGIC_LOW as 0

#define NULL_PTR    ((void*)0)   // Define NULL_PTR as a null pointer (cast to void*)

typedef unsigned char         uint8;          /*           0 .. 255              */
typedef signed char           sint8;          /*        -128 .. +127             */
typedef unsigned short        uint16;         /*           0 .. 65535            */
typedef signed short          sint16;         /*      -32768 .. +32767           */
typedef unsigned long         uint32;         /*           0 .. 4294967295       */
typedef signed long           sint32;         /* -2147483648 .. +2147483647      */
typedef unsigned long long    uint64;         /*       0 .. 18446744073709551615  */
typedef signed long long      sint64;         /* -9223372036854775808 .. 9223372036854775807 */
typedef float                 float32;        /* Single-precision floating-point */
typedef double                float64;        /* Double-precision floating-point */

#endif  /* STD_TYPES_H_ */   // End of include guard