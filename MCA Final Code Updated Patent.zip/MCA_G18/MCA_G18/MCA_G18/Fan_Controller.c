/* 
   File: Fan_Controller.c
   Description: Main program for controlling the refrigerated truck system.
                It handles the fan, Peltier module, and buzzer control based on the temperature
                and displays the relevant information on an OLED screen.
               
   MCA SCE: Microcontroller-based Overheat Detector using Temperature Sensor with Buzzer Indication
   Application: Refrigerated Truck
   Group Members: Manas Kulkarni, Rajlakshmi Desai, Samiksha Nalawade, Dhanashree Biradar
   Group Number: A35
 */

#include "lm35_sensor.h"
#include "i2c.h"
#include "SSD1306.h"
#include "dc_motor.h"
#include <avr/io.h>
#include "peltier.h"

#define F_CPU 12000000UL  // Define clock frequency
#include <util/delay.h>
#include "adc.h"

int main(void)
{
	// Initialize the buzzer port for output
	GPIO_setupPinDirection(BUZZER_PORT_ID, BUZZER_PIN_ID, PIN_OUTPUT);
	GPIO_writePin(BUZZER_PORT_ID, BUZZER_PIN_ID, LOGIC_LOW); // Buzzer initially OFF

	uint8 tempValue = 0;
	uint8 temp_prev = 0;
	uint8 temp_diff = 0;
	uint8 speedValue = 0;
	uint16_t buzzer_timer = 0;
	uint8 stable_count = 0;

	// ADC configuration
	ADC_ConfigType Config;
	Config.prescaler = FCPU_64;
	Config.ref_volt = AVCC;
	ADC_init(&Config);

	// Initialize modules
	i2c_init();    
	OLED_Init();   
	OLED_Clear();  
	DcMotor_Init();
	Peltier_Init();

	while(1)
	{
		temp_prev = tempValue;
		tempValue = LM35_GetTemperature();
		temp_diff = tempValue - temp_prev;

		// Fan status display
		OLED_SetCursor(0, 0);
		OLED_DisplayString((uint8_t *)"FAN IS ");

		// Fan logic with preemptive cooling
		if (tempValue <= 10 && temp_diff <= 1)
		{
			OLED_DisplayString((uint8_t *)"OFF ");
			DcMotor_Rotate(STOP, 0, 0);
			speedValue = 0;
		}
		else
		{
			OLED_DisplayString((uint8_t *)"ON  ");

			if (tempValue >= 18 || (temp_diff >= 2 && tempValue >= 9))
				speedValue = 100;
			else if(tempValue >= 17)
				speedValue = 75;
			else if(tempValue >= 12)
				speedValue = 50;
			else
				speedValue = 25;

			DcMotor_Rotate(ClockWise, speedValue, speedValue);
		}

		// Peltier control
		uint8 peltierDuty = Peltier_Control(tempValue);
		OLED_SetCursor(4, 0);
		OLED_DisplayString((uint8_t *)"PELTIER: ");
		OLED_DisplayNumber(C_DECIMAL_U8, peltierDuty, 3);
		OLED_DisplayString((uint8_t *)"%");

		// Buzzer logic
		if (tempValue >= 11)
		{
			if (buzzer_timer == 0)
			{
				GPIO_writePin(BUZZER_PORT_ID, BUZZER_PIN_ID, LOGIC_HIGH);
				_delay_ms(200);
				GPIO_writePin(BUZZER_PORT_ID, BUZZER_PIN_ID, LOGIC_LOW);
				buzzer_timer = 4;
			}
			else
			{
				buzzer_timer--;
			}
		}
		else
		{
			GPIO_writePin(BUZZER_PORT_ID, BUZZER_PIN_ID, LOGIC_LOW);
			buzzer_timer = 0;
		}

		// OLED power saving and temperature display logic
		if (temp_diff == 0)
		{
			stable_count++;
			if (stable_count > 10)
				OLED_DisplayOff();  // Turn off OLED if stable
		}
		else
		{
			stable_count = 0;
			OLED_DisplayOn();  // Reactivate OLED
		}

		// Display temperature and fan speed (periodically when stable)
		if (stable_count <= 10 || (stable_count % 6 == 0))
		{
			OLED_SetCursor(1, 0);
			OLED_DisplayString((uint8_t *)"TEMP = ");
			OLED_DisplayNumber(C_DECIMAL_U8, tempValue, 3);
			OLED_DisplayString((uint8_t *)" C");

			OLED_SetCursor(3, 0);
			OLED_DisplayString((uint8_t *)"SPEED: ");
			OLED_DisplayNumber(C_DECIMAL_U8, speedValue, 3);
		}

		_delay_ms(500);
	}
}
