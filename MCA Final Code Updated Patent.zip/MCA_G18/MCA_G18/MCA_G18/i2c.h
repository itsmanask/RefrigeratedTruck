/* 
   File: i2c.h
   Description: This header file contains functions and macros for I2C communication,
                including initialization, data transmission, reception, and error handling.
               
   MCA SCE: Microcontroller-based Overheat Detector using Temperature Sensor with Buzzer Indication
   Application: Refrigerated Truck
   Group Members: Manas Kulkarni, Rajlakshmi Desai, Samiksha Nalawade, Dhanashree Biradar
   Group Number: A35
 */

#ifndef i2c_h  // Include guard to prevent multiple inclusions
#define i2c_h

// Define the I2C frequency (100 kHz)
#define F_I2C 100000LL

// Define status codes for transmission success and error states
#define TRANSMISSION_SUCCESS -1  // Successful transmission
#define TRANSMISSION_ERROR -2    // Transmission error

// Define status for bus connection state
#define BUS_CONNECTED -3         // I2C bus connected
#define BUS_DISCONNECTED -4      // I2C bus disconnected

// Define the modes for master transmission and reception
#define MASTER_TRANSMITTER 0     // Mode for master to transmit data
#define MASTER_RECEIVER 1        // Mode for master to receive data

// Define acknowledgment values (ACK or NACK)
#define ACK 0                    // Acknowledge signal

// Define timeout value in terms of retries
#define TIMEOUT 50               // Timeout limit for communication retries

// Define a boolean type for the code
typedef uint8_t bool;           // Boolean type using uint8_t

/* 
 Function to initialize the I2C communication.
 This will configure the necessary I2C registers.
*/
void i2c_init(void);

/* 
 Function to start I2C communication (either for master transmission or reception).
 Arguments:
    mode - boolean value indicating whether the mode is transmitter or receiver
 Returns:
    Transmission success or error code
*/
uint8_t i2c_tx_start(bool mode);

/* 
 Function to send an I2C address.
 Arguments:
    address - I2C address to send
 Returns:
    Transmission success or error code
*/
uint8_t i2c_tx_address(uint8_t address);

/* 
 Function to transmit a byte of data via I2C.
 Arguments:
    byteData - Data byte to send
 Returns:
    Transmission success or error code
*/
uint8_t i2c_tx_byte(uint8_t byteData);

/* 
 Function to handle I2C bus timeout.
 Returns:
    Timeout status (either bus connected or disconnected)
*/
int8_t i2c_timeout(void);

/* 
 Function to receive a byte of data via I2C.
 Arguments:
    acknack - If ACK should be sent back to master or NACK
 Returns:
    Received data byte or transmission error code
*/
uint8_t i2c_rx_byte(bool acknack);

/* 
 Function to stop the I2C communication (send stop condition).
*/
void i2c_tx_stop(void);

#endif  // End of include guard