#include "dc_motor.h"
#include "pwm.h"

void DcMotor_Init(void)
{
	// Set direction control pins as output
	GPIO_setupPinDirection(MOTOR_PINS_PORT_ID, MOTOR_IN1_PIN_ID, PIN_OUTPUT);
	GPIO_setupPinDirection(MOTOR_PINS_PORT_ID, MOTOR_IN2_PIN_ID, PIN_OUTPUT);
	GPIO_setupPinDirection(MOTOR_PINS_PORT_ID, MOTOR_IN3_PIN_ID, PIN_OUTPUT);
	GPIO_setupPinDirection(MOTOR_PINS_PORT_ID, MOTOR_IN4_PIN_ID, PIN_OUTPUT);

	// Stop motors initially
	GPIO_writePin(MOTOR_PINS_PORT_ID, MOTOR_IN1_PIN_ID, LOGIC_LOW);
	GPIO_writePin(MOTOR_PINS_PORT_ID, MOTOR_IN2_PIN_ID, LOGIC_LOW);
	GPIO_writePin(MOTOR_PINS_PORT_ID, MOTOR_IN3_PIN_ID, LOGIC_LOW);
	GPIO_writePin(MOTOR_PINS_PORT_ID, MOTOR_IN4_PIN_ID, LOGIC_LOW);
}

void DcMotor_Rotate(DcMotor_State state, uint8 speedMotor1, uint8 speedMotor2)
{
	switch (state)
	{
		case STOP:
		GPIO_writePin(MOTOR_PINS_PORT_ID, MOTOR_IN1_PIN_ID, LOGIC_LOW);
		GPIO_writePin(MOTOR_PINS_PORT_ID, MOTOR_IN2_PIN_ID, LOGIC_LOW);
		GPIO_writePin(MOTOR_PINS_PORT_ID, MOTOR_IN3_PIN_ID, LOGIC_LOW);
		GPIO_writePin(MOTOR_PINS_PORT_ID, MOTOR_IN4_PIN_ID, LOGIC_LOW);
		break;

		case ClockWise:
		GPIO_writePin(MOTOR_PINS_PORT_ID, MOTOR_IN1_PIN_ID, LOGIC_LOW);
		GPIO_writePin(MOTOR_PINS_PORT_ID, MOTOR_IN2_PIN_ID, LOGIC_HIGH);
		GPIO_writePin(MOTOR_PINS_PORT_ID, MOTOR_IN3_PIN_ID, LOGIC_LOW);
		GPIO_writePin(MOTOR_PINS_PORT_ID, MOTOR_IN4_PIN_ID, LOGIC_HIGH);
		break;

		case Anti_ClockWise:
		GPIO_writePin(MOTOR_PINS_PORT_ID, MOTOR_IN1_PIN_ID, LOGIC_HIGH);
		GPIO_writePin(MOTOR_PINS_PORT_ID, MOTOR_IN2_PIN_ID, LOGIC_LOW);
		GPIO_writePin(MOTOR_PINS_PORT_ID, MOTOR_IN3_PIN_ID, LOGIC_HIGH);
		GPIO_writePin(MOTOR_PINS_PORT_ID, MOTOR_IN4_PIN_ID, LOGIC_LOW);
		break;
	}

	// Send two duty cycles separately to PWM module
	PWM_Timer1_Start(speedMotor1, speedMotor2);
}
