/* 
 File: adc.c
 Description: Contains functions to initialize the ADC and read analog values 
              from a specified ADC channel on the microcontroller.
              
 MCA SCE: Microcontroller based Overheat detector using Temperature sensor with Buzzer indication
 Application: Refrigerated Truck
 Group Members: Manas Kulkarni, Rajlakshmi Desai, Samiksha Nalawade, Dhanashree Biradar
 Group Number: A35
 */

#include "adc.h"  // Include the header file that contains ADC configurations and function declarations

// Function to initialize the ADC peripheral with the configuration provided
void ADC_init(const ADC_ConfigType * Config_Ptr)
{
	// Set the reference voltage based on the lower 2 bits of ref_volt field in the structure
	ADMUX = ((Config_Ptr->ref_volt & 0x03) << REFS0);

	// Enable ADC and set the prescaler using the lower 3 bits of the prescaler field
	ADCSRA = (1 << ADEN) | (Config_Ptr->prescaler & 0x07);
}

// Function to read analog value from a specific ADC channel
uint16 ADC_readChannel(ADC_Channel_ID channel_num)
{
	// Clear the previous channel selection and set the new one (only lower 3 bits are used for channel number)
	ADMUX = (ADMUX &= 0xE0) | (channel_num & 0x07);

	SET_BIT(ADCSRA,ADSC);              // Start ADC conversion by setting ADSC bit
	while(BIT_IS_CLEAR(ADCSRA,ADIF));  // Wait until conversion is complete (ADIF becomes 1)
	SET_BIT(ADCSRA,ADIF);              // Clear ADIF by writing '1' to it (as per datasheet)
	return ADC;                        // Return the digital result from ADC data registers
}