/* 
   File: lm35_sensor.c
   Description: Contains the function to read the temperature from the LM35 sensor 
                and convert it to Celsius temperature.
               
   MCA SCE: Microcontroller-based Overheat Detector using Temperature Sensor with Buzzer Indication
   Application: Refrigerated Truck
   Group Members: Manas Kulkarni, Rajlakshmi Desai, Samiksha Nalawade, Dhanashree Biradar
   Group Number: A35
 */

#include "lm35_sensor.h"

uint8 LM35_GetTemperature(void)
{
    uint16 adcValue = ADC_readChannel(SENSOR_CHANNEL_ID);

    // Convert ADC value to temperature (�C)
    uint8 tempValue = (uint8)(((uint32)adcValue * 500) / 1024);
    return tempValue;
}