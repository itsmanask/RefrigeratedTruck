/* 
 File: adc.h
 Description: Contains definitions, enums, and function prototypes for configuring and using 
              the ADC (Analog to Digital Converter) in the microcontroller.
              
 MCA SCE: Microcontroller based Overheat detector using Temperature sensor with Buzzer indication
 Application: Refrigerated Truck
 Group Members: Manas Kulkarni, Rajlakshmi Desai, Samiksha Nalawade, Dhanashree Biradar
 Group Number: A35
 */

#ifndef ADC_H_
#define ADC_H_

#include <avr/io.h>       // AVR input/output register definitions
#include "Macros.h"       // Include custom macros (assumed to contain SET_BIT, etc.)
#include "std_types.h"    // Include standard types like uint8, uint16

#define ADC_MAXIMUM_VALUE     1023     // Maximum digital value for 10-bit ADC
#define ADC_REF_VOLT_VALUE    2.56     // Reference voltage used for ADC conversion

// Enum to select the Reference Voltage of the ADC
typedef enum{
	AREF,               // External reference voltage at AREF pin
	AVCC,               // AVCC with external capacitor at AREF pin
	RESERVED,           // Reserved option (not used)
	INTERNAL_VREF       // Internal 2.56V reference with external capacitor at AREF pin
}ADC_ReferenceVoltage;

// Enum to select the division factor between F_CPU and F_ADC
typedef enum{
	FCPU_2,             // Division factor = 2
	FCPU_4 = 2,         // Division factor = 4
	FCPU_8,             // Division factor = 8
	FCPU_16,            // Division factor = 16
	FCPU_32,            // Division factor = 32
	FCPU_64,            // Division factor = 64
	FCPU_128            // Division factor = 128
}ADC_Prescaler;

// Enum to select which ADC Channel (0 to 7) will be used
typedef enum{
	ADC0, ADC1, ADC2, ADC3, ADC4, ADC5, ADC6, ADC7
}ADC_Channel_ID;

// Struct to configure ADC by selecting suitable Reference Voltage and Prescaler
typedef struct{
	ADC_ReferenceVoltage ref_volt;  // Reference voltage selection
	ADC_Prescaler prescaler;        // Prescaler selection
}ADC_ConfigType;

// Function to initialize the ADC with specified configurations
void ADC_init(const ADC_ConfigType * Config_Ptr);

// Function to read the analog value from the specified ADC channel
uint16 ADC_readChannel(ADC_Channel_ID channel_num);

#endif